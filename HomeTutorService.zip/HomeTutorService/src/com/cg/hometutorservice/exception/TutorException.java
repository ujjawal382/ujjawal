package com.cg.hometutorservice.exception;

public class TutorException {
	
	public TutorException()
	{
		super();
	}
	public TutorException(String msg)
	{
		System.out.println(msg);
	}


}
